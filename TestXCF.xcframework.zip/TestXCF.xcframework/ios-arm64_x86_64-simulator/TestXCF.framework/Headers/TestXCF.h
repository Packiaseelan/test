//
//  TestXCF.h
//  TestXCF
//
//  Created by Packiaseelan S on 18/12/22.
//

#import <Foundation/Foundation.h>

//! Project version number for TestXCF.
FOUNDATION_EXPORT double TestXCFVersionNumber;

//! Project version string for TestXCF.
FOUNDATION_EXPORT const unsigned char TestXCFVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestXCF/PublicHeader.h>


